<?php
/**
* @version 1.0.1
* @package Jim
* @copyright (C) 2006 Laurent Belloeil
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @website www.comeonjoomla.net
*/

function com_uninstall () 
{
		echo "Jim Successfully Uninstalled";

}


?>                                                                                                                                                                                                                                                  
