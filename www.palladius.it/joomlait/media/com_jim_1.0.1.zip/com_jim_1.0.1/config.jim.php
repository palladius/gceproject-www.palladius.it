<?php
/**
* @version 1.0.1
* @package Jim
* @copyright (C) 2006 Laurent Belloeil
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @website www.comeonjoomla.net
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$JimConfig['emailnotify']= _CMN_NO;
$JimConfig['msgbox_cols']=45;
$JimConfig["msgbox_rows"]=10;
$JimConfig["refresh_rate"]=10;
$JimConfig["hide_user"]="admin";
$JimConfig["autocomplete"]=_CMN_YES;
$JimConfig["link2cb"]=_CMN_NO;
$JimConfig["Jim_css"]=_CMN_NO;
?>
